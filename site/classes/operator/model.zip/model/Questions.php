<?php

import('operator.model.basemodel');

class Questions extends BaseModel
{
    const WAITING_CHECK = 1;        // 待审核
    const WAITING_DEAL = 2;         // 待处理
    const DEALED = 3;               // 待确认
    const WAITING_CHANGE = 4;       // 待修改
    const CANNOT_DEAL = 5;          // 无法解决
    const CHECK_DEAL = 6;           // 已确认

    const BUG = 1;                  // 系统bug
    const MISTAKE = 2;              // 操作失误

    public static function findAll($field = '*')
    {
        $base = new BaseModel();
        return $base->selectAll('questions', $field);
    }

    /**
     * @param string $field
     * @param array $where
     * @param array $order
     * @param int $limit
     * @return array|false|PDOStatement
     */
    public static function find($field = '*', $where = [], $order = [], $limit = 10, $offset = 0)
    {
        $base = new BaseModel();
        return $base->select('questions', $field, $where, $order, $limit, $offset);
    }

    public static function add($date = [])
    {
        $base = new BaseModel();
        return $base->insert('questions', $date);
    }

    public static function update($date, $where)
    {
        $base = new BaseModel();
        return $base->updates('questions', $date, $where);
    }

    /**
     * 获取发起人id
     * @param $question_id
     * @return bool
     */
    public static function getPromoterId($question_id)
    {
        $result = self::find('promoter',[['and', 'id', $question_id]]);
        if($result){
            return $result[0]['promoter'];
        }
        return false;
    }

    /**
     * 获取处理人id
     * @param $question_id
     * @return bool
     */
    public static function getDealId($question_id)
    {
        $result = self::find('dealer',[['and', 'id', $question_id]]);
        if($result){
            return $result[0]['dealer'];
        }
        return false;
    }

    public static function getTotalNum()
    {
        $result = self::find('id', [], [], 0);
        return count($result);
    }

    public static function getStatsText($stats)
    {
        switch ($stats){
            case self::WAITING_CHECK:
                $text = '待审核';
                break;
            case self::WAITING_DEAL:
                $text = '待解决';
                break;
            case self::DEALED:
                $text = '待确定';
                break;
            case self::WAITING_CHANGE:
                $text = '待修改';
                break;
            case self::CANNOT_DEAL:
                $text = '不能解决';
                break;
            default:
                $text = '异常状态';
        }
        return $text;
    }

    public static function getNextId()
    {
        $sql = "select AUTO_INCREMENT from INFORMATION_SCHEMA.TABLES where TABLE_NAME='questions'";
        $base = new BaseModel();
        $result = $base->pdo->query($sql);
        $result = $result->fetchAll(PDO::FETCH_ASSOC);
        return intval($result[0]['AUTO_INCREMENT']);
    }
}