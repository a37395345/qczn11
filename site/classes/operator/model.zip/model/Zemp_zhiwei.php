<?php

import('operator.model.basemodel');

class Zemp_zhiwei extends BaseModel
{
    public static function find($field, $where = [], $order = [], $limit = 0)
    {
        $base = new BaseModel();
        return $base->select('zemp_zhiwei', $field, $where, $order, $limit);
    }
}