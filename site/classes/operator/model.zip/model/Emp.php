<?php

import('operator.model.basemodel');
import('operator.model.admin_rule');
import('operator.model.department');
import('operator.model.zemp_zhiwei');

class emp extends BaseModel
{
    /**
     * 根据用户ID查询用户名
     * @param $id
     * @return string
     */
    public static function getNameById($id)
    {
        if(empty($id) || $id <= 0){
            return '';
        }

        $base = new BaseModel();
        $name = $base->select('emp', 'emp_name', [['and', 'emp_id', $id]]);
        if(isset($name[0]['emp_name'])){
            return $name[0]['emp_name'];
        }

        return '用户不存在';
    }

    public static function find($field = '*', $where = [], $order = [], $limit = 10)
    {
        $base = new BaseModel();
        return $base->select('emp', $field, $where, $order, $limit);
    }


    public static function checkLimit($rule)
    {
        $debug = false;
        $id = $_SESSION['user_id'];
        $rule_id = Admin_rule::find('id', [['and', 'name', $rule]]);
        if($rule_id){
            $rule_id = $rule_id[0]['id'];
            $user_info = self::find('emp_zhiweiid',[['and', 'emp_id', $id]]);
            if($user_info){
                $user_info = $user_info[0];

                $zhiwei = Zemp_zhiwei::find('rules', [['and', 'id', $user_info['emp_zhiweiid']]]);
                if(isset($zhiwei[0]['rules'])){
                    $zhiwei_rules = $zhiwei[0]['rules'];
                    if(!empty($zhiwei_rules)){
                        $zhiwei_rules = explode(',', $zhiwei_rules);
                        if(in_array($rule_id, $zhiwei_rules)){
                            return true;
                        }
                        if($debug)
                            echo '不在职位权限中';
                        // 不在职位权限中
                        return false;
                    }
                    if($debug)
                        echo '职位无权限';
                    // 职位无权限
                    return false;
                }
            }
            if($debug)
                echo '用户不存在';
            // 用户不存在
            return false;
        }else{
            if($debug)
                echo '权限未添加';
            // 权限未添加
            return false;
        }
    }

    /**
     * 根据权限获取对应权限用户id
     * @param $rule
     * @return array|bool
     */
    public static function messageGroup($rule)
    {
        $rules = Admin_rule::find('id',[['and', 'name', $rule]]);
        if(isset($rules[0]['id'])){
            $rule_id = $rules[0]['id'];
            $zhiwei = Zemp_zhiwei::find('id,rules');
            $zhiwei_group = [];
            foreach ($zhiwei as $value){
                $zhiwei_rules = explode(',', $value['rules']);
                if(in_array($rule_id, $zhiwei_rules)){
                    $zhiwei_group[] = $value['id'];
                }
            }

            if(empty($zhiwei_group)) {
                return false;
            }

            $where = [];
            foreach ($zhiwei_group as $val){
                $where[] = ['or', 'emp_zhiweiid', $val];
            }
            $users = Emp::find('emp_id', $where);

            if(empty($users)){
                return false;
            }
            $user_id = array_column($users, 'emp_id');
            return $user_id;
        }else{
            return false;
        }
    }


    /**
     * 检查用户是否在职
     * @param $id
     * @return bool
     */
    public static function checkEmpActive($id)
    {
        $user = Emp::find('emp_stutas', [['and', 'emp_id', $id]]);
        if(isset($user[0]['emp_stutas'])){
            if($user[0]['emp_stutas'] == 1){
                return true;
            }
        }
        return false;
    }
}