<?php

import('operator.model.basemodel');
import('operator.model.emp');

class Xinxi extends BaseModel
{
    /**
     * 获取消息列表
     * @return array|false|PDOStatement|null
     */
    public static function getMessageList()
    {
        // 未读消息变已读
        $result = self::update(['type' => 1], [
            ['and', 'statur', 0],
            ['and', 'type', 0],
            ['and', 'jieshou_id', $_SESSION['user_id']]
        ]);

        if($result !== false){
            $list = self::find('*', [['and', 'statur', 0], ['and', 'jieshou_id', $_SESSION['user_id']]], [], 1000);
            foreach ($list as $key => $value){
                $list[$key]['fasong_emp'] = Emp::getNameById($value['fasong_id']);
                $list[$key]['addtime'] = date('Y-m-d H:i', $value['addtime']);
            }
            return $list;
        }
        return null;
    }

    /**
     * 根据id软删除信息
     * @param $id
     * @return bool
     */
    public static function deleteMessage($id)
    {
        $result = self::update(['statur' => 1], [['and', 'id', $id]]);
        if($result !== false){
            return true;
        }
        return false;
    }

    /**
     * 获取未读信息数
     * @return int
     */
    public static function getMessageNum()
    {

        $list = self::find('id', [
            ['and', 'statur', 0],
            ['and', 'type', 0],
            ['and', 'jieshou_id', $_SESSION['user_id']]
        ], [], 1000);
        return $list !== false ? count($list) : 0;
    }












    public static function find($field = '*', $where = [], $order = [], $limit = 10)
    {
        $base = new BaseModel();
        return $base->select('xinxi', $field, $where, $order, $limit);
    }

    public static function add($date = [])
    {
        $base = new BaseModel();
        return $base->insert('xinxi', $date);
    }

    public static function update($date, $where)
    {
        $base = new BaseModel();
        return $base->updates('xinxi', $date, $where);
    }
}