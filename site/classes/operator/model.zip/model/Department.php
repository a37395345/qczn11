<?php

import('operator.model.basemodel');

class Department extends BaseModel
{
    public static function find($field, $where)
    {
        $base = new BaseModel();
        return $base->select('department', $field, $where);
    }
}